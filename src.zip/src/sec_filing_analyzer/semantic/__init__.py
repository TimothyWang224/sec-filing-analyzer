"""
Semantic data processing and storage modules for SEC filing analyzer.
"""
