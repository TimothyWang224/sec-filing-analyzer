"""
Semantic data processing modules for SEC filing analyzer.
"""
