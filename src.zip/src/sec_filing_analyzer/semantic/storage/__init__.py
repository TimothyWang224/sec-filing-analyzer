"""
Semantic data storage modules for SEC filing analyzer.
"""
