"""Utility functions for the SEC Filing Analyzer."""
